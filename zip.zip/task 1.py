def print_greeting():
    print("Hello, World!")

print_greeting()
