def print_lyrics():
    lyrics = """\
    This is the song that never ends
    It just goes on and on, my friends
    Some people started singing it not knowing what it was
    And they'll continue singing it forever just because
    """
    print(lyrics)

# Call the function to display the lyrics
print_lyrics()
