def add_numbers(a, b):
    return a + b

result = add_numbers(10, 20)
print(result)
