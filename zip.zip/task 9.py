def multiply_numbers(a, b):
    return a * b

# Use the function to multiply 7 and 8, and print the result
result = multiply_numbers(7, 8)
print(result)

