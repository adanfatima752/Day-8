def convert_to_float(num):
    return float(num)

result = convert_to_float(42)
print(result)
