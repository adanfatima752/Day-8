def calculate_expression():
    result = 1 + 2 * float(3) / 4 - 5
    return result

# Call the function and print the result
print(calculate_expression())
